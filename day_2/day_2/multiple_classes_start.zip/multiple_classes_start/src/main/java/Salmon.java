public class Salmon {
}
